import UIKit
let Welcome = "Welcome to the Egg Timer"

for index in 1...6 {
    print ("\(index) times 30 is \(index * 30)")
}

//When Timer Stops
var Timer = 180

if Timer == 180 {
    print ("Timer Stopped")
} else {
    print("Timer is On")
}
